/*! EPub UI - v13.8.16 - 2013-08-19
* http://epub.anfengde.com
* Copyright (c) 2013 AnFengDe Team; Licensed MIT */
/**
 * book class define
 * 
 * @class
 * @name Book
 */
var Book = function(id, title, author, coverImage) {
    this.id = (typeof id === 'undefined') ? '' : id;
    this.title = (typeof title === 'undefined') ? '' : title;
    this.author = (typeof author === 'undefined') ? '' : author;
    this.coverImage = (typeof coverImage === 'undefined') ? '' : coverImage;
};

/**
 * book shelf widget
 * <ul>
 * <li>manage books:add,remove,move book data
 * <li>display boosk: image or list view
 * <li>event manage: select, move, open book
 * <li>misc:customize show style-css, html, images
 * </ul>
 * 
 * <ul>
 * <li>TODO:add list view for bookshelf
 * <li>TODO:add sort(catalog) function for list view
 * <li>TODO:support customize html for book shelf
 * </ul>
 * 
 * <ul>
 * Related CSS:
 * <li>.afd-shelf : shelf css definition, don't change this name, but you can
 * add sub define for customize widget
 * </ul>
 * 
 * @class
 * @name $.mobil.shelf
 */
(function($, undefined) {
    $.widget("mobile.shelf", $.mobile.widget, {
        /**
         * book shelf options, include book data, image, type......
         */
        options : {
            /**
             * Book object array {Array.Book}
             */
            books : [],
            /**
             * book's shadow and selected image {string}
             * 
             */
            images : {
                shadow : './images/bookbase.png',
                selected : './images/selected.png',
                background : ''
            },
            /**
             * the shelf show type:image or list
             */
            type : 'image',
            /**
             * set book tap event state: 'open' or 'select'
             */
            state : 'open',
            /**
             * open book view page, this function is callback function which
             * need caller register
             * 
             * @function
             * @param {Book}
             *            the books object
             */
            openBook : function(book) {
                // do nothing, disable jshint warning
                return book;
            }
        },
        /**
         * tap book handler: open book or make selected tag
         */
        _tapBookHandler : function(event) {
            // if not in selected status then open book
            var self = event.data.self;
            return self.options.state === 'select' ? self.select(event) : self.openBook($(event.currentTarget).attr('id'));
        },
        _create : function() {
            this.element.addClass('afd-shelf');
            this.refresh();
        },

        /**
         * set book selected image or not
         * 
         * @function
         * @param {Event}
         *            tap or click event object
         */
        select : function(event) {
            var img = $(event.currentTarget).children('.afd-book-image').children('.afd-book-selected');
            img.css("visibility", img.css("visibility") === "visible" ? "hidden" : "visible");
        },
        /**
         * trigger tap event by book id. The book id must be unique global.
         * 
         * @function
         * @param {string}
         *            book id
         */
        selectById : function(id) {
            $('#' + id).trigger('tap');
        },
        /**
         * return selected books id
         * 
         * @function
         */
        selected : function() {
            var selected = [];
            $.grep(this.element.children(), function(v) {
                if ('visible' === $(v).children('.afd-book-image').children('.afd-book-selected').css("visibility")) {
                    selected.push($(v).attr('id'));
                }
                return true;
            });
            return selected;
        },
        /**
         * set all book selected status
         * 
         * @function
         * @param {boolean}
         *            show selected status when flag is true.
         * @memberOf $.mobile.shelf
         */
        selectAll : function(flag) {
            if (typeof flag === 'undefined') {
                flag = $('.afd-book-selected').css("visibility") === "hidden";
            }
            $('.afd-book-selected').css("visibility", flag ? "visible" : "hidden");
        },
        /**
         * add books to shelf,and clear or select tag
         * 
         * @function
         * @param {Array.Books}
         *            the books array.
         * @memberOf $.mobile.shelf
         */
        addBooks : function(books) {
            this.options.books = $.merge(this.options.books, books);
            this.refresh();
        },
        /**
         * remove books from shelf
         * 
         * @function
         * @param {Array.string}
         *            the books id array.
         * @memberOf $.mobile.shelf
         */
        removeBooks : function(ids) {
            // check ids is array or not
            var arr = [];
            if (ids instanceof Array) {
                arr = ids;
            } else {
                arr.push(ids);
            }

            // remove data from array
            this.options.books = $.grep(this.options.books, function(v) {
                return ($.inArray(v.id, arr) === -1) ? true : false;
            });

            // remove html element
            $.grep(this.element.children(), function(v) {
                if ($.inArray(v.id, arr) === -1) {
                    return true;
                }

                $('#' + v.id).remove();
                return false;
            });
        },
        /**
         * open book by call callback function register
         * 
         * @function
         * @param {string}
         *            the books id
         * @memberOf $.mobile.shelf
         */
        openBook : function(id) {
            if (this.options.openBook !== null && typeof this.options.openBook === 'function') {
                this.options.openBook(this.getBook(id));
            }
        },
        /**
         * get book object by id
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        getBook : function(id) {
            var res = $.grep(this.options.books, function(v) {
                return (v.id === id);
            });
            return res.length === 1 ? res[0] : null;
        },
        /**
         * get books image view html string
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        _getImageHtml : function() {
            var o = $.extend(this.options, this.element.jqmData('options'));
            var html = [];
            for ( var i = 0; i < o.books.length; i++) {
                html.push("<ul class='afd-book' id='");
                html.push(o.books[i].id);
                html.push("'><li class='afd-book-image'><img class='afd-book-cover' src='");
                html.push(o.books[i].coverImage);
                html.push("' /><img class = 'afd-book-selected afd-shelf-img' style = 'visibility:hidden' src='");
                html.push(o.images.selected);
                html.push("' /></li><li><img class='afd-shelf-img' src='");
                html.push(o.images.shadow);
                html.push("' /></li></ul>");
            }
            return html.join("");
        },
        /**
         * get books list view html string
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        _getListHtml : function() {
            var o = $.extend(this.options, this.element.jqmData('options'));
            var html = [];
            for ( var i = 0; i < o.books.length; i++) {
                html.push("<ul class='afd-book' id='");
                html.push(o.books[i].id);
                html.push("'><li class='afd-book-image'><img class='afd-book-cover' src='");
                html.push(o.books[i].coverImage);
                html.push("' /><img class = 'afd-book-selected afd-shelf-img' style = 'visibility:hidden' src='");
                html.push(o.images.selected);
                html.push("' /></li>");
                html.push("'</ul>");
            }
            return html.join("");
        },
        /**
         * refresh book shelf
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        refresh : function() {
            this.element.children().remove();
            this.element.append("image" === this.options.type ? this._getImageHtml() : this._getListHtml());
            this.element.children('.afd-book').on('tap', {
                self : this
            }, this._tapBookHandler);
        }
    });

    $(document).bind("pagecreate create", function(e) {
        $(e.target).find(":jqmData(role='shelf')").shelf();
    });
})(jQuery, this);

(function($, undefined) {

    /**
     * book shelf navigator bar class
     * 
     * @class
     * @name $.shelfNavi
     */
    $.shelfNavi = {
        /*
         * change book shelf show style
         */
        shelfViewSwitch : function() {
            var btn = $("#btn_shelf .ui-btn-text");
            if ("List" === btn.text()) {
                btn.text("Shelf");
                $('#books').shelf('option', 'type', 'list');
            } else {
                btn.text("List");
                $('#books').shelf('option', 'type', 'image');
            }
            $('#books').shelf('refresh');
        },
        /*
         * show edit toolbar
         */
        bookEditBarShow : function() {
            $('#shelf_edit').show();
            $('#books').shelf('option', 'state', 'select');
        },
        /*
         * clear select status and hide toolbar
         */
        bookDone : function() {
            $('#books').shelf('selectAll', false);
            $("#shelf_edit").hide();
            $('#books').shelf('option', 'state', 'open');
        },
        /*
         * delete selected book from shelf
         */
        bookRemove : function() {
            $('#books').shelf('removeBooks', $('#books').shelf('selected'));
        },
        /*
         * select all book or deselect all book
         */
        bookAll : function() {
            $('#books').shelf('selectAll');
        },
        /*
         * show add book page
         */
        bookAdd : function() {
            $.mobile.changePage('#upload');
        },
        /**
         * open book view page
         * 
         * @function
         * @param {Book}
         *            the books object
         */
        openBook : function(book) {
            book = null;
            $.mobile.changePage($('#bookview'), 'pop');
        },
        // TODO:hard code for debug
        addTestData : function() {
            var books = [];
            var book = new Book('1', 'Eight Weeks Of Bruce', 'Koman', './images/book1.png');
            books.push(book);

            book = new Book('2', 'Flowers', 'Martin', './images/book2.png');
            books.push(book);

            book = new Book('3', 'The Pearl', 'John', './images/book3.png');
            books.push(book);

            book = new Book('4', 'White And Red', 'Yellow', './images/book4.png');
            books.push(book);

            book = new Book('5', 'Bed Fellows', 'Richard', './images/book5.png');
            books.push(book);

            book = new Book('6', 'Light', 'Adison', './images/book6.png');
            books.push(book);

            book = new Book('7', 'Sea And Hill', 'Mcphee', './images/book7.png');
            books.push(book);

            book = new Book('8', 'What is this', 'Dixon', './images/book8.png');
            books.push(book);

            book = new Book('9', 'Little Bee', 'Long', './images/book9.png');
            books.push(book);

            return books;
        },
        /*
         * register handler
         */
        setHandlers : function() {
            $("#btn_shelf_view").on('tap', this.shelfViewSwitch);
            $("#btn_shelf_edit").on('tap', this.bookEditBarShow);
            $("#book_done").on('tap', this.bookDone);
            $("#book_remove").on('tap', this.bookRemove);
            $("#book_all").on('tap', this.bookAll);
            $("#book_add").on('tap', this.bookAdd);
        }
    };

    // TODO:define bookview object

}(jQuery, window));
