/*! EPub UI - v13.8.16 - 2013-09-22
* http://epub.anfengde.com
* Copyright (c) 2013 AnFengDe Team; Licensed MIT */
/**
 * book class define
 * 
 * @class
 * @name Book
 */
/* exported Book */
var Book = function(id, title, author, coverImage) {
    this.id = (typeof id === 'undefined') ? '' : id;
    this.title = (typeof title === 'undefined') ? '' : title;
    this.author = (typeof author === 'undefined') ? '' : author;
    this.coverImage = (typeof coverImage === 'undefined') ? '' : coverImage;
};

/**
 * book shelf widget
 * <ul>
 * <li>manage books:add,remove,move book data
 * <li>display boosk: image or list view
 * <li>event manage: select, move, open book
 * <li>misc:customize show style-css, html, images
 * </ul>
 * 
 * <ul>
 * </ul>
 * 
 * <ul>
 * Related CSS:
 * <li>.afd-shelf : shelf css definition, don't change this name, but you can
 * add sub define for customize widget
 * </ul>
 * 
 * @class
 * @name $.mobil.shelf
 */
(function($, undefined) {
    $.widget("mobile.shelf", $.mobile.widget, {
        /**
         * book shelf options, include book data, image, type......
         */
        options : {
            /**
             * Book object array {Array.Book}
             */
            books : [],
            /**
             * book's selected image {string}
             * 
             */
            images : {
                selected : './images/selected.png',
                background : ''
            },
            /**
             * the shelf show type:image or list
             */
            type : 'image',
            /**
             * set book tap event state: 'open' ,'remove' or 'select'
             */
            state : 'open',
            /**
             * open book view page, this function is callback function which
             * need caller register
             * 
             * @function
             * @param {Book}
             *            the books object
             */
            openBook : function(book) {
                // do nothing, disable jshint warning
                return book;
            }
        },
        /**
         * tap book handler: open book or make selected tag
         */
        _tapBookHandler : function(event) {
            // if not in selected status then open book
            var self = event.data.self;
            event.preventDefault();
            if (self.options.state === 'select') {
                return self.select(event);
            }

            if (self.options.state === 'remove') {
                if (1 === $(event.currentTarget).find('.ui-icon-delete').length) {
                    self.options.state = 'open';
                    return self.removeBooks($(event.currentTarget).attr('id'));
                }
            }

            return self.openBook($(event.currentTarget).attr('id'));
        },
        _create : function() {
            this.element.addClass('afd-shelf');
            this.refresh();
        },

        /**
         * set book selected image or not
         * 
         * @function
         * @param {Event}
         *            tap or click event object
         */
        select : function(event) {
            var img = $(event.currentTarget).find('.afd-book-selected');
            if (img.hasClass('afd-book-selected-hidden')) {
                img.removeClass('afd-book-selected-hidden').addClass('afd-book-selected-visible');
            } else {
                img.removeClass('afd-book-selected-visible').addClass('afd-book-selected-hidden');
            }
        },
        /**
         * trigger tap event by book id. The book id must be unique global.
         * 
         * @function
         * @param {string}
         *            book id
         */
        selectById : function(id) {
            $('#' + id).trigger('tap');
        },
        /**
         * return selected books id
         * 
         * @function
         */
        selected : function() {
            var selected = [];
            $.grep(this.element.children(), function(v) {
                if ($(v).find('.afd-book-selected-visible').length > 0) {
                    selected.push($(v).attr('id'));
                }
                return true;
            });
            return selected;
        },
        /**
         * set all book selected status
         * 
         * @function
         * @param {boolean}
         *            show selected status when flag is true.
         * @memberOf $.mobile.shelf
         */
        selectAll : function(flag) {
            var imgs = this.element.find('.afd-book-selected');
            if (typeof flag === 'undefined') {
                flag = imgs.hasClass('afd-book-selected-hidden');
            }
            imgs.removeClass('afd-book-selected-visible').removeClass('afd-book-selected-hidden');
            imgs.addClass(flag ? 'afd-book-selected-visible' : 'afd-book-selected-hidden');
        },
        /**
         * add books to shelf,and clear or select tag
         * 
         * @function
         * @param {Array.Books}
         *            the books array.
         * @memberOf $.mobile.shelf
         */
        addBooks : function(books) {
            this.options.books = $.merge(this.options.books, books);
            this.refresh();
        },
        /**
         * remove books from shelf
         * 
         * @function
         * @param {Array.string}
         *            the books id array.
         * @memberOf $.mobile.shelf
         */
        removeBooks : function(ids) {
            // check ids is array or not
            var arr = [];
            if (ids instanceof Array) {
                arr = ids;
            } else {
                arr.push(ids);
            }

            // remove data from array
            this.options.books = $.grep(this.options.books, function(v) {
                return ($.inArray(v.id, arr) === -1) ? true : false;
            });

            // remove html element
            $.grep(this.element.find('.afd-book'), function(v) {
                if ($.inArray(v.id, arr) === -1) {
                    return true;
                }
                $('#' + v.id).remove();

                return false;
            });

            //improve performance
            //this.refresh();
        },
        /**
         * open book by call callback function register
         * 
         * @function
         * @param {string}
         *            the books id
         * @memberOf $.mobile.shelf
         */
        openBook : function(id) {
            if (this.options.openBook !== null && typeof this.options.openBook === 'function') {
                this.options.openBook(this.getBook(id));
            }
        },
        /**
         * get book object by id
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        getBook : function(id) {
            var res = $.grep(this.options.books, function(v) {
                return (v.id === id);
            });
            return res.length === 1 ? res[0] : null;
        },
        /**
         * get books image view html string
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        _getImageHtml : function() {
            var o = $.extend(this.options, this.element.jqmData('options'));
            var html = [];
            for ( var i = 0; i < o.books.length; i++) {
                html.push("<div class='afd-shelf-img afd-book' id='");
                html.push(o.books[i].id);
                html.push("'><div><img class='afd-book-cover' src='");
                html.push(o.books[i].coverImage);
                html.push("'><img class='afd-book-selected afd-book-selected-hidden' src='");
                html.push(o.images.selected);
                html.push("'></div><div class='book-shadow'></div></div>");
            }
            return html.join("");
        },
        /**
         * get books list view html string
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        _getListHtml : function() {
            var o = $.extend(this.options, this.element.jqmData('options'));
            var html = [];
            html.push("<ul data-role='listview' id='shelf_list' data-filter='true' data-inset='true'>");
            for ( var i = 0; i < o.books.length; i++) {
                html.push("<li class='afd-shelf-list afd-book' id='");
                html.push(o.books[i].id);
                html.push("'><a href='#'><div class='list-thumb'><img class='afd-book-cover' src='");
                html.push(o.books[i].coverImage);
                html.push("'/></div><div class='list-desc'><div class='book-title'>");
                html.push(o.books[i].title);
                html.push("</div><div class='book-author'>");
                html.push(o.books[i].author);
                html.push("</div><div class='book-introduction'>");
                html.push(o.books[i].title);
                html.push("</div></div></a><a href='#' class='split-button-custom' data-role='button' data-icon='arrow-r' data-iconpos='notext'>Open Book</a></li>");
            }
            html.push("</ul>");
            return html.join("");
        },
        /**
         * refresh book shelf
         * 
         * @function
         * @memberOf $.mobile.shelf
         */
        refresh : function() {
            this.element.children().remove();
            this.element.append("image" === this.options.type ? this._getImageHtml() : this._getListHtml());

            // register open book handler
            this.element.find('.afd-book').on('tap', {
                self : this
            }, this._tapBookHandler);

            if ("list" === this.options.type) {
                this.element.find('#shelf_list').listview(); // force show jquery list
                this.element.find('#list_catalog').navbar();
                this.element.find('.afd-shelf-list').on('swiperight', {
                    self : this
                }, function(event) {
                    $(this).parent().find('.ui-icon-delete').removeClass('ui-icon-delete').addClass('ui-icon-arrow-r');
                    $(this).find('.ui-icon-arrow-r').removeClass('ui-icon-arrow-r').addClass('ui-icon-delete');
                    var self = event.data.self;
                    self.options.state = 'remove';
                });
            }
        }
    });

    $(document).bind("pagecreate create", function(e) {
        $(e.target).find(":jqmData(role='shelf')").shelf();
    });
})(jQuery, this);

(function($, undefined) {

    /**
     * book shelf navigator bar class
     * 
     * @class
     * @name $.shelfNavi
     */
    $.shelfNavi = {
        /*
         * change book shelf show style
         */
        shelfViewSwitch : function() {
            var btn = $("#btn_shelf_view .ui-btn-text");
            if ("List" === btn.text()) {
                btn.text("Shelf");
                $('#books').shelf('option', 'type', 'list');
                $('#btn_shelf_edit').hide();
                $('#books').shelf('selectAll', false);
                $("#shelf_edit").hide();
                $('#books').shelf('option', 'state', 'open');
                $('#shelf_footer').show();
            } else {
                btn.text("List");
                $('#btn_shelf_edit').show();
                $('#books').shelf('option', 'type', 'image');
                $('#shelf_footer').hide();
            }
            $('#books').shelf('refresh');
        },
        /*
         * show edit toolbar
         */
        bookEditBarShow : function() {
            $('#shelf_edit').show();
            $('#books').shelf('option', 'state', 'select');
        },
        /*
         * clear select status and hide toolbar
         */
        bookDone : function() {
            $('#books').shelf('selectAll', false);
            $("#shelf_edit").hide();
            $('#books').shelf('option', 'state', 'open');
        },
        /*
         * delete selected book from shelf
         */
        bookRemove : function() {
            $('#books').shelf('removeBooks', $('#books').shelf('selected'));
        },
        /*
         * select all book or deselect all book
         */
        bookAll : function() {
            $('#books').shelf('selectAll');
        },
        /*
         * show add book page
         */
        bookAdd : function() {
            $.mobile.changePage('#upload');
        },
        /**
         * open book view page
         * 
         * @function
         * @param {Book}
         *            the books object
         */
        openBook : function(book) {
            book = null;
            $.mobile.changePage($('#bookview'), 'pop');
        },
        /*
         * register handler
         */
        setHandlers : function() {
            $("#btn_shelf_view").on('tap', this.shelfViewSwitch);
            $("#btn_shelf_edit").on('tap', this.bookEditBarShow);
            $("#book_done").on('tap', this.bookDone);
            $("#book_remove").on('tap', this.bookRemove);
            $("#book_all").on('tap', this.bookAll);
            $("#book_add").on('tap', this.bookAdd);
        }
    };

    $(document).ready(function() {
        if (typeof $.shelfNavi.addTestData === 'function'){
            $('#books').shelf('addBooks', $.shelfNavi.addTestData());
        }

        $('#books').shelf('option', 'openBook', $.shelfNavi.openBook);

        // shelf edit bar callback
        $.shelfNavi.setHandlers();
    });

}(jQuery, window));

